<?php
if (!defined('TYPO3_MODE')) {
	die ('Access denied.');
}

require_once(t3lib_extMgm::extPath('cps_tcatree') . 'class.tx_cpstcatree.php');
?>